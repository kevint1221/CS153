#include "types.h"
#include "user.h"

int main( int argc, char * argv[])
{
	printf(1, "\n\n Hello from the user space! \n ");
	exits(2);
	waits(0);
	return 0;
}

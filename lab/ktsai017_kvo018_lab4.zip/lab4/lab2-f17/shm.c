#include "param.h"
#include "types.h"
#include "defs.h"
#include "x86.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"

struct {
  struct spinlock lock;
  struct shm_page {
    uint id; //id that process uses to search the correct address in page table
    char *frame; //what you want to translate physical address
    int refcnt;  //how many processes are in the counter
  } shm_pages[64]; //page 
} shm_table; 

void shminit() { //initialize 
  int i;
  initlock(&(shm_table.lock), "SHM lock");
  acquire(&(shm_table.lock));
  for (i = 0; i< 64; i++) {
    shm_table.shm_pages[i].id =0;
    shm_table.shm_pages[i].frame =0;
    shm_table.shm_pages[i].refcnt =0;
  }
  release(&(shm_table.lock));
}

int shm_open(int id, char **pointer) { //pointer is used for only process with same address go here

//you write this

	//check if id matches in the page table(pgdir)
	acquire(&(shm_table.lock)); //prevent race condition
	
	int i = 0;
	for(i=0; i < 64; i++) //64 is the size of shm_pages
	{
		if (id == shm_table.shm_pages[i].id) // if id matches in tha page table
		{
			
			//map the virtual address to physical address
		//	PGROUNDUP(myproc()->sz);
		//	uint * va_pointer = myproc()->sz;
			mappages(myproc()->pgdir, (char*)PGROUNDUP(myproc()->sz), PGSIZE , V2P(shm_table.shm_pages[i].frame) , PTE_W|PTE_U); //mapp virtual to physicall
			//increase a process that is using the counter
			shm_table.shm_pages[i].refcnt++; //there is a process which is accessing counter
			//return the pointer to the virtual address
			*pointer = (char*)PGROUNDUP(myproc()->sz);
			//update the pagesize of sz
			myproc()->sz = PGROUNDUP(myproc()->sz+PGSIZE);
		
			
		}
		else //if doesn't match
		{
			//initialize the id to the virtual address
			shm_table.shm_pages[i].id = id;
			//initialize the physical 
			shm_table.shm_pages[i].frame = kalloc();
			memset(shm_table.shm_pages[i].frame, 0, PGSIZE); 
			
			//set a reference counter to know that someone is accessing the counter
			shm_table.shm_pages[i].refcnt = 1;
			//map the virtual to physical
			mappages(myproc()->pgdir, (char*)PGROUNDUP(myproc()->sz), PGSIZE , V2P(shm_table.shm_pages[i].frame) , PTE_W|PTE_U); //mapp virtual to physicall
			//update page size
			*pointer = (char*)PGROUNDUP(myproc()->sz);
			myproc()->sz = PGROUNDUP(myproc()->sz+PGSIZE);				
		} 
	}
	release(&(shm_table.lock));

	return 0; //added to remove compiler warning -- you should decide what to return
}


int shm_close(int id) {
//you write this too!
	//if find id, then drecrement shm_table
	int i =0;
	acquire(&(shm_table.lock));
	for (i =0; i < 64 ; i++)
	{
		if (shm_table.shm_pages[i].id == id )
		{
			if(shm_table.shm_pages[i].refcnt != 0)
			{
				shm_table.shm_pages[i].refcnt--;
			}
			else if ( shm_table.shm_pages[i].refcnt == 1)
			{
				shm_table.shm_pages[i].id =0;
				shm_table.shm_pages[i].frame =0;
				shm_table.shm_pages[i].refcnt =0;
				
				
			}	
			
		}
		
	}	
	release(&(shm_table.lock));
	


return 0; //added to remove compiler warning -- you should decide what to return
}
